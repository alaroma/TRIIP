package com.example.var8;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;



import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.material.textfield.TextInputEditText;
import com.openalpr.jni.Alpr;
import com.openalpr.jni.AlprException;
import com.openalpr.jni.AlprResults;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class CreateLabel extends AppCompatActivity {
   // private static final int CAMERA = 1;
    private String ANDROID_DATA_DIR;
    private ImageView imageView;
    private TextView textView;
     private EditText num_rasp;
    private static File destination;
    // ProgressDialog prdi;
    private ImageView mapButton;
    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupActionBar();
        setContentView(R.layout.activity_create_label);
        imageView = findViewById(R.id.imageView2);
        num_rasp = findViewById(R.id.num_rasp);
        textView = findViewById(R.id.textView3);
        mapButton = findViewById(R.id.imageView5);

        //textView = findViewById(R.id.textView);
        //Button button = findViewById(R.id.button);
        //Button camera = findViewById(R.id.camera);
        ImageButton camera = findViewById(R.id.imageButton);
        ANDROID_DATA_DIR = this.getApplicationInfo().dataDir;

        mapButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                Intent intObj = new Intent(CreateLabel.this, MapCreateLabel.class);
                startActivity(intObj);
            }
        });

        camera.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                checkPermission(Manifest.permission.CAMERA, 0);
            }
        });

        ImageButton edit_num = findViewById(R.id.buttonEdit);
        num_rasp.setEnabled(false);

        edit_num.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                // num_rasp.setFocusableInTouchMode(true);
                num_rasp.setEnabled(true);
            }
        });

        ImageButton galery = findViewById(R.id.imageButton3);
        galery.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, 1);
            }
        });
     //   button.setOnClickListener(new View.OnClickListener() {

         //   public void onClick(View view) {
                //  takePicture();
       //         checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, 1);
              //  Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
               // photoPickerIntent.setType("image/*");
                //startActivityForResult(photoPickerIntent, 1);
           // }
        //});

        final MultiAutoCompleteTextView mp = findViewById(R.id.mp);
        final int co = getIntent().getIntExtra("count",0);
        final Double txt = getIntent().getDoubleExtra("lat", 0.0);
        final Double txt2 = getIntent().getDoubleExtra("lng", 0.0);
        if (co!=0) {

            Geocoder geocoder = new Geocoder(CreateLabel.this);
            List<Address> adr = new ArrayList<>();
            try {
                adr = geocoder.getFromLocation(txt, txt2, 1);

            } catch (IOException e) {
                e.printStackTrace();
            }

            if (adr != null) {
                Address address = adr.get(0);
                //  String add = address.getAddressLine(0) + ", " + address.getLocality();
                String add = address.getAddressLine(0);

                mp.setText(add);
            }
        }
//
        final TextInputEditText name = findViewById(R.id.name_of_label);
        final TextInputEditText tags_of_lab = findViewById(R.id.tag);
        Button addlabel = findViewById(R.id.addlabel);
        // final String strin = name.getText().toString();
        addlabel.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {


                String namelab = name.getText().toString();
                String data = textView.getText().toString();
                String tags = tags_of_lab.getText().toString();



                Intent intObj = new Intent(CreateLabel.this, Main2Activity.class);

                if(tags_of_lab.getText().toString().length()==0) {
                    tags_of_lab.setError("Это поле обязательно для заполнения!");
                }
                if(name.getText().toString().length()==0) {
                    name.setError("Это поле обязательно для заполнения!");
                }
                if (num_rasp.getText().toString().length()==0) {
                    num_rasp.setError("Это поле обязательно для заполнения!");
                }
                if (mp.getText().toString().length()==0){
                    mp.setError("Это поле обязательно для заполнения!");
                }
                if (imageView.getDrawable() == null){
                    Toast.makeText(getApplicationContext(), "Прикрепите изображение!", Toast.LENGTH_LONG).show();
                }
                if(mp.getText().toString().length()>0&&num_rasp.getText().toString().length()>0&&name.getText().toString().length()>0&&
                        tags_of_lab.getText().toString().length()>0&&imageView.getDrawable()!=null) {


                  //  try {
                        //createLabel(name.getText().toString(),
                          //      num_rasp.getText().toString(),
                            //    tags_of_lab.getText().toString(), data,
                              //  txt.toString(), txt2.toString()); //txt txt2 double!!!
                  //  } catch (JSONException e) {
                    //    e.printStackTrace();
                    //}
                    intObj.putExtra("name", namelab);
                    intObj.putExtra("data", data);
                    intObj.putExtra("tags", tags);
                    //  intObj.putExtra("code",code);
                    // intObj.putExtra("img", bitmap);
                    intObj.putExtra("img", imageView.toString());
//
                    startActivity(intObj);
                    // Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
//                    imageLoader(bitmap);




                }
            }
        });
    }

    public String dateToString(Date date, String format) {
        SimpleDateFormat df = new SimpleDateFormat(format, Locale.getDefault());

        return df.format(date);
    }

    private void checkPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, requestCode);
        } else {
            switch (requestCode) {
                case 1: {
                    choosePhoto();
                }
                case 0: {
                    takePicture();
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 0: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    takePicture();
                } else {
                    Toast.makeText(CreateLabel.this, "Разрешите доступ к камере!", Toast.LENGTH_SHORT).show();
                }
            }
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    choosePhoto();
                } else {
                    Toast.makeText(CreateLabel.this, "Разрешите доступ к памяти!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

public void choosePhoto() {
    Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
     photoPickerIntent.setType("image/*");
    startActivityForResult(photoPickerIntent, 1);
}
    public void takePicture() {
        // Use a folder to store all results
        File folder = new File(Environment.getExternalStorageDirectory() + "/OpenALPR/");
        if (!folder.exists()) {
            folder.mkdir();
        }

        // Generate the path for the next photo
        String name = dateToString(new Date(), "yyyy-MM-dd-hh-mm-ss");
        destination = new File(folder, name + ".jpg");

        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(destination));
        startActivityForResult(cameraIntent, 0);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);

        if (resultCode == RESULT_OK) {

            switch (requestCode) {
                case 0:

                    Raspoz(0, null, null);
                     showExifcam();


                    break;
                case 1:
                    Uri selectedImage2 = imageReturnedIntent.getData();
                    String Path = getRealPathFromURI(selectedImage2);
                    Raspoz(1, selectedImage2, Path);
                    showExif(selectedImage2);
                    break;
            }
        }
    }
    public String getRealPathFromURI(Uri uri) {
        if (uri == null) return null;
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            String result = cursor.getString(column_index);
            cursor.close();
            return result;

        }

        return uri.getPath();
    }
    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            // Show the Up button in the action bar.
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    String str, str2;
    SimpleDateFormat ft = new SimpleDateFormat ("dd.MM.yyyy, HH:mm", Locale.getDefault());
    @RequiresApi(api = Build.VERSION_CODES.N)
    void showExif(Uri photoUri){
        if(photoUri != null){
            try {
                InputStream inputStream = getContentResolver().openInputStream(photoUri);
                ExifInterface exifInterface = new ExifInterface(inputStream);
                //  datePh = ft.parse(str);
                //  ft.format(dateNow);
                // str2 = ft.format(dateNow);
                str = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);
                //   dateNow = ft.parse(str);

                // str2 = convertTime.format(dateNow);
                textView.setText(str);
                assert inputStream != null;
                inputStream.close();

            } catch (IOException e) {
                e.printStackTrace();

            } //catch (ParseException e) {
            //e.printStackTrace();
            //}

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    void showExifcam(){
        Date dateNow = new Date();

        textView.setText(ft.format(dateNow));
    }


    @SuppressLint("StaticFieldLeak")
    void Raspoz(final int i, Uri selectedImage2, final String path) {
        textView.setText("");
        //  final String path_dir = path.replace("JPG", "jpg");
        //   final String path_dir = path;
        final ProgressDialog progress = ProgressDialog.show(this, "Подождите", "Идет распознавание...", true);
        final String openAlprConfFile = ANDROID_DATA_DIR + File.separatorChar + "runtime_data" + File.separatorChar + "config"+ File.separatorChar + "openalpr.conf";
        String str = ANDROID_DATA_DIR + File.separatorChar + "runtime_data";
        final Alpr alpr = new Alpr(CreateLabel.this, this.getApplicationInfo().dataDir, "eu", openAlprConfFile, str);
        boolean t3 = alpr.isLoaded();
        alpr.setTopN(10);
        // alpr.setDefaultRegion("");
        alpr.setDetectRegion(false);
        // progress.show();
        //  final String openAlprConfFile = ANDROID_DATA_DIR + File.separatorChar + "runtime_data" + File.separatorChar + "openalpr.conf";

        //  if(i == 0) Picasso.with(CreateLabel.this).load(destination).into(imageView);
        //if (i==1 && selectedImage2!=null)  {
        //  imageView.setImageURI(selectedImage2);
        //}
        new AsyncTask<Void, Void, AlprResults>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progress.show();
            }

            @Override
            protected AlprResults doInBackground(Void... params) {
                AlprResults result = null;
                // String t = destination.getAbsolutePath();
                //
                try {
                    result = alpr.recognize(path);
                } catch (AlprException e) {
                    e.printStackTrace();
                }

                return result;
            }

            @Override
            protected void onPostExecute(AlprResults result) {
                progress.dismiss();
                if (result == null || result.getPlates() == null || result.getPlates().size() == 0) {
                    Toast.makeText(CreateLabel.this, "It was not possible to detect the licence plate.", Toast.LENGTH_LONG).show();
                    textView.setText("It was not possible to detect the licence plate.");
                } else {

                    textView.setText(result.getPlates().get(0).getBestPlate().getCharacters());                }
            }

//            @Override
//            protected void onProgressUpdate(Void values) {
//                super.onProgressUpdate(values);
//                progress.show();
//            }
        }.execute();

    }

    private static final String URL_FOR_REGISTRATION = "http://triip.yasya.top:80/api/v1/marks";

//    private void createLabel(final String name,  final String number, final String tags, final String data,
//                             final String lat, final String lng) throws JSONException {
//
//
//        JSONObject postparams = new JSONObject();
//        postparams.put("title", name);
//        postparams.put("car_number", number);
//        postparams.put("tags", tags);
//        postparams.put("mark_time", data);
//        postparams.put("lat", lat);
//        postparams.put("lng", lng);
        //lat lng add!!
        //data add!!!


//        JsonObjectRequest strReq = new JsonObjectRequest(DownloadManager.Request.Method.POST,
//                URL_FOR_REGISTRATION, postparams, new Response.Listener<JSONObject>() {
//            @Override
//            public void onResponse(JSONObject response) {
//            }
//
//
//        }, new Response.ErrorListener() {
//
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//            }
//        });
//
//        AppSingleton.getInstance(getApplicationContext()).addToRequestQueue(strReq, "GOOD");
//    }
}
//           AsyncTask.execute(new Runnable() {
//                                 //  String result;
//                                 AlprResults result = null;
//
//                                 @Override
//                                 public void run() {
//                                     switch (i) {
//                                         case 0:
//
//                                             //alpr.setDefaultRegion("wa");
//                                             // AlprResults results = alpr.recognize(imagedata);
//                                             // result =
//                                             //   result = Factory.create(MainActivity.this, ANDROID_DATA_DIR).recognizeWithCountryRegionNConfig("us", "",  destination.getAbsolutePath(), openAlprConfFile, 10);
//                                             try {
//                                                 String t = destination.getAbsolutePath();
//                                                 //
//                                                 result = alpr.recognize(t);
//                                                 // textView.setText(("OpenALPR Version: " + alpr.getVersion()));
//                                             } catch (AlprException e) {
//                                                 e.printStackTrace();
//                                             }
//                                             break;
//                                         case 1:
//                                             //  result = OpenALPR.Factory.create(CreateLabel.this, ANDROID_DATA_DIR).recognizeWithCountryRegionNConfig("us", "",  path_dir, openAlprConfFile, 10);
//                                             break;
//                                         default:
//                                     }
//
//
//                                     //try {
//                                     //   final AlprResults results = new JSON().fromJSON(result);
//                                     //  textView.setText("ttt");
//                                     // List<AlprResults> resultItems = result.getResultItems();
//                                     //textView.setText("OpenALPR Version: " + alpr.getVersion());
//                                     // AlprResults resultItem = resultItems.get(0);
//                                     runOnUiThread(new Runnable() {
//                                         @Override
//                                         public void run() {
//                                             if (result == null) {
//                                                 textView.setText("Found " + result.getPlates().size() + " results");
//                                             } else
//                                                 textView.setText("Found " + result.getPlates().size() + " results");
//                                         }
//                                     });
//  Toast.makeText(MainActivity.this, "Некорректное распознавание!", Toast.LENGTH_LONG).show();
// resultTextView.setText("It was not possible to detect the licence plate.");
//} else {
//  textView.setText("yyy");
// textView.setText(result.getResults().get(0).getPlate());
//}
//        progress.dismiss();
//  }
//});

//catch (JsonSyntaxException exception) {
// final ResultsError resultsError = new Gson().fromJson(result, ResultsError.class);


//    });}}
//   });
// }
//}